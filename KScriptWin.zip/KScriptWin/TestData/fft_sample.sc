﻿//	FFT
n = 5000;						//	サンプリング数
dt = 0.0001;					//	サンプリング間隔(s)
fs = 1 / dt;					//	サンプリング周波数(Hz)
t[] = array.arrange(0,n*dt,dt);
println("サンプリング数 : ",n," サンプリング間隔: ",dt,"s サンプリング周波数: ",fs," Hz");
f1 = 50;
f2 = 120;
signal[] = t[];
express = "sin(2*PI*f1*[x])+0.5*sin(2*PI*f2*[x])";
array.calc(signal[],express);

//	グラフ表示
graph.GraphType("line");
//	データ抽出サイズ
size = 500;
t2[] = array.copy(t[],0,size);
signal2[] = array.copy(signal[],0,size);
//	データグラフ
graph.SetData(t2[],signal2[]);

//	FFT Magnitude
//mag[] = math.fourier(signal[]);
//mag2[] = array.copy(mag[],0,size);
//graph.SetData(t2[],mag2[]);

//for(i=0; i<n; i+= 10) {
//	y = sin(2*PI*f1*t[i])+0.5*sin(2*PI*f2*t[i]);
//	println(t[i]," ",signal[i]);
//}
