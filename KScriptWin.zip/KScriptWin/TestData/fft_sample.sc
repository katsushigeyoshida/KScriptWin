﻿//	FFT
n = 1024;
dt = 0.001;
t[] = array.arrenge(0,n*dt,dt);
f1 = 50;
f2 = 120;
signal[] = t[];
express = "sin(2*PI*f1*[x])+0.5*sin(2*PI*f2*[x])";
println("データ数:",array.count(t[])," 最小値:",array.min(t[])," 最大値:",array.max(t[]));
println(t[]);
array.calc(signal[],express);
println("データ数:",array.count(signal[])," 最小値:",array.min(signal[])," 最大値:",array.max(signal[]));
println(signal[]);
graph.GraphType("line");
graph.SetData(t[],signal[]);
//for(i=0; i<n; i+= 10) {
//	y = sin(2*PI*f1*t[i])+0.5*sin(2*PI*f2*t[i]);
//	println(t[i]," ",signal[i]);
//}