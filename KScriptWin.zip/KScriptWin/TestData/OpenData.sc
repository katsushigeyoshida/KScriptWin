﻿//	気象庁の気候データからダウンロード(羽田は1993年以前のデータなし)
//	https://www.data.jma.go.jp/risk/obsdl/index.php
//
folder = "C:\\Users\\k-yos\\OneDrive\\一時データ\\オープンデータ\\気象データ\\";
file2026 = "data_気温_羽田_20260101-20260726.csv";
file2025 = "data_気温_羽田_20250101-20251231.csv";
file2024 = "data_気温_羽田_20240101-20241231.csv";
file2023 = "data_気温_羽田_20230101-20231231.csv";
file2022 = "data_気温_羽田_20220101-20221231.csv";
file2021 = "data_気温_羽田_20210101-20211231.csv";
file2020 = "data_気温_羽田_20200101-20201231.csv";
file2019 = "data_気温_羽田_20190101-20191231.csv";
file2018 = "data_気温_羽田_20180101-20181231.csv";
file2017 = "data_気温_羽田_20170101-20171231.csv";
file2016 = "data_気温_羽田_20160101-20161231.csv";
file2015 = "data_気温_羽田_20150101-20151231.csv";
file2014 = "data_気温_羽田_20140101-20141231.csv";
file2013 = "data_気温_羽田_20130101-20131231.csv";
file2012 = "data_気温_羽田_20120101-20121231.csv";
file2011 = "data_気温_羽田_20110101-20111231.csv";
file2010 = "data_気温_羽田_20100101-20101231.csv";
file2009 = "data_気温_羽田_20090101-20091231.csv";
file2008 = "data_気温_羽田_20080101-20081231.csv";
file2007 = "data_気温_羽田_20070101-20071231.csv";
file2006 = "data_気温_羽田_20060101-20061231.csv";
file2005 = "data_気温_羽田_20050101-20051231.csv";
file2004 = "data_気温_羽田_20040101-20041231.csv";
file2003 = "data_気温_羽田_20030101-20031231.csv";
file2002 = "data_気温_羽田_20020101-20021231.csv";
file2001 = "data_気温_羽田_20010101-20011231.csv";
file2000 = "data_気温_羽田_20000101-20001231.csv";
file1999 = "data_気温_羽田_19990101-19991231.csv";
file1998 = "data_気温_羽田_19980101-19981231.csv";
file1997 = "data_気温_羽田_19970101-19971231.csv";
file1996 = "data_気温_羽田_19960101-19961231.csv";
file1995 = "data_気温_羽田_19950101-19951231.csv";
file1994 = "data_気温_羽田_19940101-19941231.csv";
file1993 = "data_気温_羽田_19930101-19931231.csv";
file1992 = "data_気温_羽田_19920101-19921231.csv";
file1991 = "data_気温_羽田_19910101-19911231.csv";
file1990 = "data_気温_羽田_19900101-19901231.csv";


//
file[] = { 
file2026, 
file2025, file2024, file2023, file2022, file2021, 
file2020, file2019, file2018, file2017, file2016,
file2015, file2014, file2013, file2012, file2011,
file2010, file2009, file2008, file2007, file2006,
file2005, file2004, file2003, file2002, file2001,
file2000, file1999, file1998, file1997, file1996,
file1995, file1994, file1993,
};

start = 0;			//	表示開始データ
splitAreaX = 3;
splitAreaY = 5;
graph.SetSplitArea(splitAreaX,splitAreaY);
for (i = start; i < start + splitAreaX*splitAreaY; i++) {
	data[,] = loadData(folder, file[i]);
	//	グラフ表示
	graph.SetUseArea((i - start) % splitArea);
	graph.Title(file[i]);
	graph.YTitle("気温");
	graph.XTitle("日付");
	graph.SetDataArea(0,-10,366,40);
	graph.GraphType("line");
	graph.SetColor("Red");
	graph.SetData(data[,0],data[,1]);
	graph.SetColor("Blue");
	graph.AddData(data[,0],data[,3]);
}


loadData(folder,file) {
startTime();
	path = folder + file;
	println(path);
	file.setEncordingType("ShiftJis");
	array.clear(data[,]);
	data[,] = file.loadCsv(path);
println(lapTime());
	//	タイトル行削除
	for (i = 0; i < 4; i++)
		array.remove(data[i,]);
println(lapTime());
	array.squeeze(data[,]);
println(lapTime());
//	for (i = 0; i < 10;i++)
//		println(data[i,]);
//	file.saveCsv(file, data[,]);
	return data[,];
}
