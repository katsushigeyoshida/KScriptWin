﻿//	気象データのグラフ化
//	https://www.data.jma.go.jp/risk/obsdl/index.php

//folder = "C:\\Users\\k-yos\\OneDrive\\一時データ\\オープンデータ\\気象データ\\";
folder = file.getDirectory(file.getScriptPath()) + "\\気象データ\\";

start = 2026;
last  = 2010;
type = 1;			//	1:最高気温 2:最低気温 3:平均気温
//location = "札幌";
location = "羽田";

for (y = start; y >= last; y--)
	files[start - y] = "data_気温_" + location + "_" + y + ".csv";

for (i = 0; i < array.count(files[]); i++)
	legend[i] = (start-i) + "年";
for (i = 1; i <= 12; i++)
	label[i-1] = i + "月";
title[] = {"最高気温","最低気温","平均気温"};

barCount = start - last +1;	//	年データ数
barPos = 0;
colorNo = 0;

//	グラフ表示
graph.Reset();
graph.YTitle("気温");
graph.XTitle("日付");
graph.GraphType("bar");
graph.SetDataArea(-0.5,-10,11.5,40);		//	表示範囲
graph.Title(title[type - 1]+"の月別の平均");
graph.BarCount(barCount);
graph.SetColor("Black");

//	月単位の平均気温に変換
data[,] = loadData(folder, files[0]);
month[] = day2monthData(data[,],type);
// 気温表示
graph.SetFillColor(plot.GetColorName(colorNo++));
graph.SetLegend(legend[0]);
graph.BarPosition(barPos++);
graph.SetStepY(5);
graph.SetData(label[],month[]);
//	追加表示
for (i = 1; i < barCount; i++) {
	array.remove(data[,]);
	data[,] = loadData(folder, files[i]);
	month[] = day2monthData(data[,],type);
	graph.SetFillColor(plot.GetColorName(colorNo++));
	graph.SetLegend(legend[i]);
	graph.BarPosition(barPos++);
	graph.AddData(label[],month[]);
}

//	最高気温を月単位の平均に変換
day2monthData(data[,],type) {
	ave[] = array.create(12,0);
	month = 0;
	count = 0;
	string.toDouble(data[,type]);
	for (i = 0; i < array.count(data[,0]); i++) {
		date[] = string.split(data[i,0],"/");	//	日付分割
		if (date[1] != month) {
			if (0 < month) {
				ave[month-1] = sum[month-1] / count;
			}
			count = 1;
			month = string.toDouble(date[1]);
			sum[month-1] = data[i,type];
		} else {
			sum[month-1] += data[i,type];
			count++;
		}
	}
	ave[month-1] = sum[month-1] / count;
	return ave[];
}

//	気象(CSVファイル)データの読込
loadData(folder,file) {
   path = folder + file;
   print(file);
   if (file.fileExists(path) == 0) {
   	   println("not exists");
   	   exit;
   }
   file.setEncordingType("ShiftJis");
   array.clear(data[,]);
   data[,] = file.loadCsv(path);
   print(" *");
   // タイトル行削除
   for (i = 0; i < 4; i++)
      array.remove(data[i,]);
   print(" *");
   array.squeeze(data[,]);
   println(" *");
   return data[,];
}

