﻿x[] = array.arrenge(-1,20,0.5);
y[] = x[];
array.calc(y[], "([x]-10)^2");
println(array.count("x[] ",x[]),": ",x[]);
println(array.count("y[] ",y[]),": ",y[]);
//y[] = { 4, 3, 5, 2, 1 };
data[,] = { {1,2},{2,3},{3,4},{4,5},{5,6}};
title = "TEST";
gtype[] = {"line", "scatter", "bar" };
graph.FontSize(12);
graph.Title("てすと");
graph.XTitle("X-title");
graph.YTitle("Y-title");

graph.GraphType(gtype[0]);
graph.LineType("solid");
graph.SetColor("Black");
graph.SetData(x[], y[]);

graph.GraphType(gtype[1]);
graph.SetColor("Red");
graph.PointType("circle");
graph.PointSize(2);
graph.AddData(x[],y[]);

//graph.Set(data[,], title);
plot.Color("Blue");
plot.Line(0,0,20,100);
