﻿//	我が家の電気量(2005年6月以降)
// https://www.kenshin.tepco.co.jp/
data[,] = {
//    1月   2月   3月  4月  5月  6月  7月  8月  9月 10月 11月 12月
	{   0,   0,   0,   0,   0,  97, 108, 111, 156, 114, 100, 126 },	//	2005年
	{ 179, 123, 121, 121, 142, 104, 107, 131, 130, 108, 109, 134 },	//	2006年
	{ 159, 140, 141, 132, 139, 108, 105, 159, 146, 121,  99, 132 },	//	2007年
	{ 211, 145, 136, 123, 117,  90, 100, 136, 130, 125, 108, 135 },	//	2008
	{ 179, 125, 147, 135, 110,  99, 117, 137, 137, 103,  96, 130 },	//	2009
	{ 130, 168, 130, 171, 154, 113, 142, 168, 211, 127, 128, 127 },	//	2010
	{ 212, 178, 146, 144, 140, 113, 121, 134, 162, 124, 121, 115 },	//	2011
	{ 156, 119, 113, 106, 137, 112, 113, 149, 151, 136, 120, 152 },	//  2012
	{ 181, 168, 147, 112, 103,  97, 112, 133, 130, 119, 102, 119 },	//  2013
	{ 193, 154, 144, 110, 113,  90, 112, 128, 115, 123, 101, 111 },	//  2014
	{ 178, 157, 143, 133, 105, 109, 111, 139, 129, 119, 108, 139 },	//  2015
	{ 130, 125, 114, 113, 120, 101, 108, 138, 123, 114, 111, 107 },	//  2016
	{ 135, 116, 106, 101, 118, 100, 116, 135, 113, 121, 114, 139 },	//  2017
	{ 151, 118, 118, 110, 133, 117, 134, 202, 152, 134, 127, 135 },	//  2018
	{ 157, 167, 122, 129, 123, 129, 139, 194, 189, 151, 124, 144 },	//  2019
	{ 151, 160, 117, 134, 126, 144, 132, 169, 235, 144, 126, 152 },	//  2020
	{ 189, 184, 145, 116, 126, 123, 134, 213, 183, 127, 127, 120 },	//  2021
	{ 191, 183, 127, 135, 137, 132, 166, 221, 168, 162, 121, 129 },	//  2022
	{ 155, 166, 125, 122, 133, 132, 170, 252, 210, 143,  92,  95 },	//  2023
	{ 125, 123, 130, 107,  90,  88, 139, 184, 140, 128,  95, 102 },	//  2024
	{ 138, 133, 111, 116,  83,  83, 146, 184, 164, 106,  92,  87 },	//  2025
	{ 114, 126,  81,  87,  92,  68,  90, 156,   0,   0,   0,   0 },	//  2026
};
n = 0;
for (i = 1; i <=12; i++)
	month[n++] = i + "月";
n = 0;
for (i = 2005; i <= 2026; i++)
	yearLabel[n++] = i + "年";

start = 2018;
last = 2026;

graph.Reset();
graph.SetSplitArea(1,2);

// 月別電気量グラフ
graph.SetUseArea(0);
graph.Title("月別電気量(日平均)");
graph.YTitle("電気量(kW)");
graph.XTitle("日付");
graph.GraphType("bar");
barCount = last - start + 1;
barPos = 0;
graph.BarCount(barCount);
graph.SetColor("Black");
graph.SetDataArea(-0.5,0,11.5,300);
colorNo = 0;
graph.SetFillColor(plot.GetColorName(colorNo++));
graph.BarPosition(barPos++);
graph.SetLegend(yearLabel[start - 2005]);
graph.SetData(month[], data[start - 2005,]);

for (y = 1; y < barCount; y++) {
	graph.SetFillColor(plot.GetColorName(colorNo++));
	graph.BarPosition(barPos++);
	yearPos = start - 2005 + y;
	graph.SetLegend(yearLabel[yearPos]);
	println(yearLabel[yearPos]);
	graph.AddData(month[], data[yearPos,]);
}

//	特定月の電気量の推移(2005年以降)
array.remove(label[]);
for (y = 2005; y <= 2026; y++)
	label[i++] = y + "年";

start = 1;
last = 12;

graph.SetUseArea(1);
graph.Title("月別電気量(日平均)");
graph.YTitle("電気量(kW)");
graph.XTitle("日付");
graph.GraphType("line");
graph.SetDataArea(0,0,22,300);
graph.SetColor(plot.GetColorName(colorNo++));
graph.LineThickness(3);
label = start + "月";
graph.SetLegend(label);
graph.SetData(label[], data[,start - 1]);

for (m = start + 1; m <= last; m++) {
	graph.SetColor(plot.GetColorName(colorNo++));
	label = m + "月";
	graph.SetLegend(label);
	graph.AddData(label[], data[,m - 1]);
}
