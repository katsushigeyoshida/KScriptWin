﻿//	気象庁の気候データからダウンロード(羽田は1993年以前のデータなし)
//	https://www.data.jma.go.jp/risk/obsdl/index.php
//
//folder = "C:\\Users\\k-yos\\OneDrive\\一時データ\\オープンデータ\\気象データ\\";
folder = file.getDirectory(file.getScriptPath()) + "\\気象データ\\";
println(folder);

start = 2026;
last  = 2000;
//location = "札幌";
location = "羽田";

//	ファイル名作成
for (y = start; y >= last; y--)
   files[start - y] = "data_気温_" + location + "_" + y + ".csv";
println(files[]);

//	グラフ作成
splitArea = 6;		//	全分割数(グラフ数)
splitAreaX = 1;		//	横分割数
for (i = 0; i < splitArea; i++)
	wetherGraph(folder,files[i],splitArea,splitAreaX,i,1,2);


//	フォルダ,ファイル名,全分割数,横分割数,分割位置,最高気温カラム,最低気温カラム
wetherGraph(folder,file,splitArea,splitAreaX,useArea,high,low) {
	//	ファイルからデータの読込
	path = folder + file;
	println(path);
	file.setEncordingType("ShiftJis");
	array.clear(data[,]);
	data[,] = file.loadCsv(path);
	// データからタイトル行削除
	for (i = 0; i < 4; i++)
		array.remove(data[i,]);
	array.squeeze(data[,]);
//	file.saveCsv(file, data[,]);
	// グラフ表示
	splitAreaY = splitArea/splitAreaX;
	graph.SetSplitArea(splitAreaX,splitAreaY);
	graph.SetUseArea(useArea);
	graph.Title(file);
	graph.YTitle("気温");
	graph.XTitle("日付");
	graph.GraphType("line");
	graph.SetDataArea(0,-20,366,40);
	//	最高気温
	graph.SetColor("Red");
	graph.SetData(data[,0],data[,high]);
	//	最低気温
	graph.SetColor("Blue");
	graph.AddData(data[,0],data[,low]);
}