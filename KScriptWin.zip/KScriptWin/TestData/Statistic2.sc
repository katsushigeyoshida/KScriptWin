﻿a[] =  { 30, 50, 70, 40, 80 };
std = array.stdDeviation(a[]);
println("標準偏差 : ",std);
println(array.average(a[]));
println(array.sum(a[]));

x[] = {  2,  4,  7,  8,  9 };
y[] = { 30, 50, 70, 40, 80 };
cov = array.covariance(x[],y[]);
xstd = array.stdDeviation(x[]);
ystd = array.stdDeviation(y[]);
println("共分散 : ",cov," xの標準偏差 : ",xstd," yの標準偏差 : ",ystd);
cor = array.corrCoeff(x[],y[]);
println("相関係数 : ",cor);
