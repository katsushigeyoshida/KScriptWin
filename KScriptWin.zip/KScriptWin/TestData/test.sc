﻿a[,] = {{1,2,3},{4,5,6},{7,8,9}};
b[] = {8,9};
array.insert(a[,],1,b[]);
for(i = 0; i <= array.maxIndex(a[,0]); i++) {
	for(j = 0; j <= array.maxIndex(a[i,]); j++)
		print(i,",",j,": ",a[i,j],"  ");
	println();
}
