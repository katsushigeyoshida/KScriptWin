﻿folder = file.getDirectory(file.getScriptPath()) + "\\気象データ\\";
println(folder);
sub(folder);
folder2 = "C:\\Users\\k-yos\\OneDrive\\Document\\KScriptWin\\TestData\\気象データ\\";
println(folder2);
sub(folder2);


sub(arg) {
	println(arg);
}