﻿#include "scriptLib.sc";
//	2D座標変換
p[,]={{2,3},{3,4},{5,6}};
v[]={1,2};
c[,]=matrix.translate(p[,],v[]);
printArray2(c[,]);
c[,]=matrix.rotate(p[,],RAD(45));
printArray2(c[,]);
c[,]=matrix.rotate(c[,],RAD(-45));
printArray2(c[,]);
sc[] = { 2,3};
c[,] = matrix.scale(p[,],sc[]);
printArray2(c[,]);

//	3D座標変換
p[,] ={{2,3,1},{3,4,2},{5,6,3}};
v[]={1,2,3};
c[,]=matrix.translate3D(p[,],v[]);
printArray2(c[,]);
c[,] = matrix.rotate3D(p[,],RAD(45),"X");
printArray2(c[,]);
