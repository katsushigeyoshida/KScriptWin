﻿#include "scriptLib.sc";

//	球体の表示
p[,] = sphereQuads(10, 16);
//printArray2(a[,]);
//exit;

sp = -2;
ep =  2;
min[] = { sp, sp, sp };
max[] = { ep, ep, ep };
plot3D.setArea(min[],max[]);
plot3D.setAxisFrame(1,0);

plot3D.setColor("MediumAquamarine");
plot3D.plotQuads(p[,]);
plot3D.plotQuadeStrip(rectSide[,]);

//	球体データ(QUADS)
sphereQuads(r,n) {
	if (n <= 0)
		n = 32;
	a[,] = arc(r,n,0,PI);
	cl[,] = { { 0,0,0}, {1,0,0}};
	divAng = 2 * PI / n;
	sa = 0; ea = 2 * PI;
	p[,] = plot3D.polylinRotateQuads(a[,],cl[,],divAng,sa,ea);
	return p[,];
}


//	円弧座標データ
arc(r,n,sa,ea) {
    step = 2 * PI / n;
    i = 0;
    z = 0;
    for (ang = sa; ang - step < ea; ang += step) {
    	if (ea < ang) ang = ea;
        x = r * cos(ang);
        y = r * sin(ang);
        pos[i, 0] = x;
        pos[i, 1] = y;
        pos[i, 2] = z;
        i++;
    }
    return pos[,];
}

//  円座標データ
circle(r,n) {
    step = 2 * PI / n;
    i = 0;
    z = 0;
    for (ang  = 0; ang < 2 * PI; ang += step) {
        x = r * cos(ang);
        y = r * sin(ang);
        pos[i, 0] = x;
        pos[i, 1] = y;
        pos[i, 2] = z;
        i++;
    }
    return pos[,];
}

//  長方形の座標データ
rectangle(w, h) {
    p[0,] = { 0, 0, 0 };
    p[1,] = { w, 0, 0 };
    p[2,] = { w, h, 0 };
    p[3,] = { 0, h, 0 };
    return p[,];
}